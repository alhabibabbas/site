---
title: Homepage
language: en
slug: /
---

# Simplicity, Hugo theme.

Lorem ipsum dolor sit amet, consectetur adipiscing elit.

[Posts](/posts/) &bull; [Categories](/categories/) &bull; [Tags](/tags/)

[Photos](/photos/) &bull; [Projects](/projects/)
