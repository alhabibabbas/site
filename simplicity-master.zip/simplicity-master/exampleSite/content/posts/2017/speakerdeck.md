---
title: Speakerdeck
date: 2017-07-09T10:15:01+02:00
categories: [writing]
tags: [typography, elements]
language: en
slug: speakerdeck
---

```markdown
{{</* speakerdeck 50021f75cf1db900020005e7 */>}}
```

{{< speakerdeck 50021f75cf1db900020005e7 >}}