---
title: Video
date: 2018-06-09T10:15:01+02:00
categories: [writing]
tags: [typography, elements]
language: en
slug: video
---

```markdown
{{</* video src="media/video.mp4" */>}}
```

{{< video src="media/video.mp4" >}}
