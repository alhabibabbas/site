---
title: Tables
date: 2018-01-09T10:15:01+02:00
categories: [writing]
tags: [typography, elements]
language: en
slug: tables
---

First Header | Second Header | Third Header
------------ | ------------- | ------------
Content Cell | Content Cell  | Content Cell
Content Cell | Content Cell  | Content Cell

---

| First Header  | Second Header |
| ------------- | ------------- |
| Content Cell  | Content Cell  |
| Content Cell  | Content Cell  |

---

First Header | Second Header | Third Header
:----------- | :-----------: | -----------:
Left         | Center        | Right
Left         | Center        | Right

---

&nbsp;       | &nbsp;        | &nbsp;
:----------- | :-----------: | -----------:
Left         | Center        | Right
Left         | Center        | Right
