---
title: Numbered list with code
date: 2019-01-06T12:17:01+02:00
categories: [writing]
tags: [typography, elements]
language: en
slug: numbered-list-with-code
---

1. Test 1.

    ```bash
    test 1
    ```
2. Test 2.

    ```bash
    test 2
    ```

3. Test 3.

    ```bash
    test 3
    ```
